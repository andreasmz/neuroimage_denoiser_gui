import sys
import time

print("Encoding of called test1.py",sys.stdout.encoding)