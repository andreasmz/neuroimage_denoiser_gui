import time
import sys


print("Starting")
#sys.stdout.flush() 
time.sleep(2)
print("Middle")
#sys.stdout.flush() 
time.sleep(2)
print("End")