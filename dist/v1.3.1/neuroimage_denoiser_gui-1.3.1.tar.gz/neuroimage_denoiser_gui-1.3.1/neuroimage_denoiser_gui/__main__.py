from .window import NDenoiser_GUI

if __name__ == "__main__":
    gui = NDenoiser_GUI()