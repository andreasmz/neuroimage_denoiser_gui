# C 2025 Andreas Brilka
# This script is used for creating standalone exe using pyinstaller

import neuroimage_denoiser
import neuroimage_denoiser_gui
gui = neuroimage_denoiser_gui.NDenoiser_GUI()